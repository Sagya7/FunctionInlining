package visitor;
import java.io.*;
import java.util.*;

public class FunInfo
{
    public Map<String, VarInfo> functions = new HashMap<>();
}