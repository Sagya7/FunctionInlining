package visitor;
import java.io.*;
import java.util.*;

public class FunDef
{
    public List<String> list_string = new ArrayList<>();
    public FunInfo fun_info = new FunInfo();
    public VarInfo var_info = new VarInfo();
    public Map<String, List<String>> class_hirarchy = new HashMap<>();
    public Map<String, FunInfo> functions_def = new HashMap<>();
    public Map<String, VarInfo> class_global_variables = new HashMap<>();
}