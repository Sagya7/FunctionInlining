package visitor;
import java.io.*;
import java.util.*;

public class Buffer
{
    public List<String> code_chain = new ArrayList<>();
    public List<String> global_code = new ArrayList<>();
    public List<String> curret_method_code = new ArrayList<>();
    public List<String> temp_code = new ArrayList<>();
    public FunDef cha_analysed = new FunDef();
    public String current_class_name;
    public String current_method_name;
    public List<String> current_args = new ArrayList<>();
    public boolean is_func_monomorphic;
    public String inlinable_class_name;
}