package visitor;
import java.io.*;
import java.util.*;

public class VarInfo
{
    public Map<String, String> varinfo = new HashMap<>();
}