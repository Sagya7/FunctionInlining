//Array Allocation
class test14{
    public static void main(String[] a){
        A obj1;
        B obj2;
        int temp1;
        int temp2;
        int const1;
        int const2;
        
        obj1 = new A();
        obj2 = new B();
        const1 = 10;
        const2 = 15;
        temp1 = obj1.ComputeFac(const1, const2);
        temp2 = obj2.ComputeFac(const1, const2);
        System.out.println(temp1);
    }
}

class A extends B{
    public int ComputeFac(int num, int num2, int num3){
        return num ;
    }

    public int ComputeFac(int num, int num2){
        return num ;
    }

    public int SecondFunc(int num)
    {
        return num;
    }
}

class B {
    public int ComputeFac(int num, int num2){
        return num ;
    }
}

class C extends B{
    public int ComputeFac(int num){
        return num ;
    }
}

class D extends B{
    public int ComputeFac(int num){
        return num ;
    }
}

class E extends C{
    public int ComputeFac(int num){
        return num ;
    }
}
class F extends D{
    public int ComputeFac(int num){
        return num ;
    }
}

