//This testcase deals with Funnction overloading with
// class inheritance.
class test2{
    public static void main(String[] a){
        A2 obj1;
        B2 obj2;
        int const1;
        int const2;
        int temp1;
        int temp2;
        const1 = 4;
        const2 = 5;
        
        obj1 = new A2();
        obj2 = new B2();

        temp1 = obj1.ComputeFac(const1, const2);
        temp2 = obj2.ComputeFac(const1, const2);

        System.out.println(temp1);
        System.out.println(temp2);
    }
}

class A2 extends B2{
    int i;
    public int ComputeFac(int num, int num2, int num3){
        int i;
        return num ;
    }

    public int SecondFunc(int num)
    {
        int j;
        return num;
    }
}

class B2{
    int i;
    public int ComputeFac(int num, int num2){
        int k;
        return num ;
    }
}


