import syntaxtree.*;
import visitor.*;
import java.io.*;
import java.util.*;
import java.util.stream.*;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;

public class P4_debug {
	public static void main(String [] args) {
		GJDepthFirst v = new GJDepthFirst();
		GJDepthFirstCHA v1 = new GJDepthFirstCHA();
		try{
				try
				{
                    FileInputStream stream = null;
					stream = new FileInputStream("test1.java");
					Node root = new FunkyTacoJavaParser(stream).Goal();
					//System.out.println("Program parsed successfully");
                    FunDef cha = new FunDef();
					//SymbolTable st = new SymbolTable();
					root.accept(v1, cha);

				
					//populate symbol table
                    Buffer buf = new Buffer();
                    buf.cha_analysed = cha;
					root.accept(v, buf);
    				int i = 0;
					while(i < buf.code_chain.size())
					{
						System.out.println(buf.code_chain.get(i));
						i++;
					}
				}
				catch(Exception e)
				{
					e.printStackTrace();
				}
			}
			catch (Exception e)
			{
			 System.out.println(e.toString());
			}
	}
}
