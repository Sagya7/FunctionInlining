class test1 {
  public static void main(String[] a) {
    A1 obj1;
    int const1;
    int temp1;
    const1 = 4;
    obj1 = new A1();
    temp1 = obj1.ComputeFac(const1, const1, const1) yesinline & A1 &
            ComputeFac / int / int / int;
    System.out.println(temp1);
  }
}
class A1 {
  int i;
  public int ComputeFac(int num, int num2, int num3) {
    int i;
    i = 5;
    return i;
  }
  public int ComputeFac(int num) {
    int j;
    j = 7;
    return j;
  }
}
