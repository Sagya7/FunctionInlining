//This testcase chceks whether can we check the function
// is monomorphic when the derived class getting access to
// to the function from base class.

class test4{
    public static void main(String[] a){
        A4 obj1;
        B4 obj2;
        int const1;
        int const2;
        int temp1;
        int temp2;
        const1 = 4;
        const2 = 5;
        
        obj1 = new A4();
        obj2 = new B4();

        temp1 = obj1.ComputeFac(const1, const2, const2);
        temp2 = obj2.SecondFunc(const1);

        System.out.println(temp1);
        System.out.println(temp2);
    }
}

class A4 extends B4{
    int i;
    public int ComputeFac(int num, int num2, int num3){
        int i;
        return num ;
    }

}

class B4{
    int i;
    public int ComputeFac(int num, int num2, int num3){
        int k;
        return num ;
    }

    public int SecondFunc(int num)
    {
        int j;
        return num;
    }
}


