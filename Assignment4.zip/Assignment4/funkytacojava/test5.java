//this function helps with function overridings

class test5{
    public static void main(String[] a){
        B5 obj2;
        int const1;
        int const2;
        int temp1;
        boolean e1;
        const1 = 4;
        const2 = 5;
        e1 = const1 < const2;
        if(e1)
        {
            obj2 = new A5();
        }
        else
        {
            obj2 = new B5();
        }
        
        temp1 = obj2.ComputeFac(const1, const2, const2);

        System.out.println(temp1);
    }
}

class A5 extends B5{
    int i;
    public int ComputeFac(int num, int num2, int num3){
        int i;
        return num ;
    }

}

class B5{
    int i;
    public int ComputeFac(int num, int num2, int num3){
        int k;
        return num ;
    }

    public int SecondFunc(int num)
    {
        int j;
        return num;
    }
}


